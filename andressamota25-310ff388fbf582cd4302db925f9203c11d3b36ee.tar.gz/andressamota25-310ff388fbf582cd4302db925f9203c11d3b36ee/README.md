# Your Fit Best Friend

#### Video Demo: [URL HERE](https://youtu.be/dMJYYyMNQ5k)

#### Description:
This is my CS50 final project - I've created a web-based application using JavaScript, Python, and SQL for people to get a free workout plan upon subscription. There are 3 options based on the user's choice: 3, 4, or 5-day workout plans.

- **General Structure**:
  First, I created the project directory and added the `app.py` file to serve as the Flask application. This file contains the application logic and an SQLite database.
  - Includes a function to initialize the database (referencing the [SQLite documentation](https://docs.python.org/3/library/sqlite3.html)).
  - Implements routes for the home page using `GET` and `POST` methods.
  - Features a redirection function to guide users to the appropriate workout plan based on their subscription choice.

- **Index File**:
  The `index.html` file embeds the user registration form, subscription questions, and page header.

- **Workout Files**:
  The workout plans are split into three HTML files:
  - `workout_day3.html`
  - `workout_day4.html`
  - `workout_day5.html`
  Each file includes a table with the respective workout plan and extends settings from the `index.html` file using Jinja2 templating.

- **CSS File**:
  The `styles.css` file contains the visual settings and styles for the web application.

### TODO:
- [ ] Additional features to improve user experience.
- [ ] Testing and debugging.
