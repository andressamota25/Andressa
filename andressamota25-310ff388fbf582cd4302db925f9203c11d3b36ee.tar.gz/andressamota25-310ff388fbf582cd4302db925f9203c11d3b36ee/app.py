from flask import Flask, render_template, request
import sqlite3  # Import sqlite3 without CS50

app = Flask(__name__)

# Function to initialize the database (learned from the sql documentation from Python (https://docs.python.org/3/library/sqlite3.html))
def init_db():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    # Create the 'users' table if it doesn't exist // error proof
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL,
        days INTEGER NOT NULL,
        gender TEXT NOT NULL,
        height REAL NOT NULL,
        weight REAL NOT NULL
    )
    """)
    conn.commit()
    conn.close()

# Setting the routes for the home page // same as from week 9 class, using GET and POST
@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        # Get data from the form
        name = request.form.get("name")
        age = request.form.get("age")
        days = request.form.get("days")
        gender = request.form.get("gender")
        height = request.form.get("height")
        weight = request.form.get("weight")

        # Return failure message if not registered properly
        if not (name and age and days and gender and height and weight):
            return "Failure: All fields are required."

        # Initialize the database and insert data into the users table
        init_db()  # Connects the users file to sqlite Database
        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (name, age, days, gender, height, weight) VALUES (?, ?, ?, ?, ?, ?)",
            (name, age, days, gender, height, weight),
        )
        conn.commit()
        conn.close()

        # Redirect based on the number of workout days
        days = int(days)  # Convert days to integer
        if days == 3:
            return render_template("workout_day_3.html", name=name)
        elif days == 4:
            return render_template("workout_day_4.html", name=name)
        else:
            return render_template("workout_day_5.html", name=name)

    return render_template("index.html")

# Initialize the database before the app runs
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
